<?php
// Database credentials
$host = 'localhost';
$dbname = 'form';
$username = 'form_user';
$password = 'Asdfghjkl1!';

// Establish a database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: Could not connect. " . $e->getMessage());
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_NUMBER_INT);
    $website = filter_var($_POST['website'], FILTER_SANITIZE_URL);
    $message = htmlspecialchars($_POST['message']);

    // Check if email already exists in the database
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM form_data WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $result = $stmt->fetch();

    if ($result['count'] > 0) {
        // Email already exists, do not insert new record
        echo "Email already exists in the database.";
    } else {
        // Email does not exist, insert new record
        $sql = "INSERT INTO form_data (name, email, phone, website, message, submission_date) VALUES (:name, :email, :phone, :website, :message, NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['name' => $name, 'email' => $email, 'phone' => $phone, 'website' => $website, 'message' => $message]);
        echo "Record added successfully.";
    }
}
?>
