<?php
include('table_db_conn.php');

if (isset($_POST['id'])) {
    $id = $_POST['id'];
    $stmt = $pdo->prepare("DELETE FROM form_data WHERE id = ?");
    if ($stmt->execute([$id])) {
        header("Location: index.php"); // Redirect back to the admin page
        exit();
    } else {
        echo "Failed to delete the record.";
    }
}
?>
