<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Admin</title>
    <meta name="viewport" content="initial-scale=1.0; maximum-scale=1.0; width=device-width;">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Styles for the modal popup */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

        .modal-button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin: 4px 2px;
            cursor: pointer;
            border-radius: 5px;
        }

        /* Styles for the notification area */
        .notification {
            display: none;
            background-color: #f2f2f2;
            color: #333;
            text-align: center;
            padding: 10px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="table-title">
    <h3>Submitted Contact Details</h3>
</div>
<table class="table-fill">
    <thead>
    <tr>
        <th class="text-left">Name</th>
        <th class="text-left">Email</th>
        <th class="text-left">Phone</th>
        <th class="text-left">Website</th>
        <th class="text-left">Message</th>
        <th class="text-left">Date</th>
        <th class="text-left">Actions</th>
    </tr>
    </thead>
    <tbody class="table-hover">
    <?php
    include('table_db_conn.php'); // Include the new database connection script

    // Fetch data from the database
    $stmt = $pdo->query("SELECT id, name, email, phone, website, message, submission_date FROM form_data");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($data)) {
        foreach ($data as $row): ?>
            <tr id="row_<?php echo $row['id']; ?>">
                <td class="text-left"><?php echo $row['name']; ?></td>
                <td class="text-left"><?php echo $row['email']; ?></td>
                <td class="text-left"><?php echo $row['phone']; ?></td>
                <td class="text-left"><?php echo $row['website']; ?></td>
                <td class="text-left"><?php echo $row['message']; ?></td>
                <td class="text-left"><?php echo $row['submission_date']; ?></td>
                <td class="text-left">
                    <form id="deleteForm_<?php echo $row['id']; ?>" action="delete.php" method="post">
                        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                        <button type="button" onclick="confirmDelete(<?php echo $row['id']; ?>)">Delete</button>
                        <button type="button" onclick="copyMessage(<?php echo $row['id']; ?>)">Copy</button>
                    </form>
                </td>
            </tr>
        <?php endforeach;
    } else {
        echo '<tr><td colspan="7">No records found</td></tr>';
    }
    ?>
    </tbody>
</table>

<!-- Modal popup for confirmation -->
<div id="myModal" class="modal">
    <div class="modal-content">
        <p>Are you sure you want to delete this record?</p>
        <button class="modal-button" id="modalYes">Yes</button>
        <button class="modal-button" id="modalNo">No</button>
    </div>
</div>

<!-- Notification area for message copy -->
<div id="notification" class="notification"></div>

<script>
    let currentRowId = null;

    function confirmDelete(id) {
        currentRowId = id;
        document.getElementById("myModal").style.display = "block";
    }

    document.getElementById("modalYes").addEventListener("click", function() {
        if (currentRowId !== null) {
            // Submit the form for deletion
            document.getElementById("deleteForm_" + currentRowId).submit();
        }
    });

    document.getElementById("modalNo").addEventListener("click", function() {
        document.getElementById("myModal").style.display = "none";
        currentRowId = null;
    });

    function copyMessage(id) {
        var message = document.getElementById("row_" + id).cells[4].textContent;
        navigator.clipboard.writeText(message).then(function() {
            document.getElementById("notification").innerText = "Message copied to clipboard";
            document.getElementById("notification").style.display = "block";
            setTimeout(function() {
                document.getElementById("notification").style.display = "none";
            }, 3000); // Hide the notification after 3 seconds
        }).catch(function() {
            document.getElementById("notification").innerText = "Failed to copy message.";
            document.getElementById("notification").style.display = "block";
            setTimeout(function() {
                document.getElementById("notification").style.display = "none";
            }, 3000); // Hide the notification after 3 seconds
        });
    }
</script>
</body>
</html>
