<?php
// Database credentials
$host = 'localhost';
$dbname = 'form';
$username = 'form_user';
$password = 'Asdfghjkl1!';

// Establish a database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error: Could not connect. " . $e->getMessage());
}

// Fetch data from the database
$stmt = $pdo->query("SELECT name, email, phone, website, message FROM form_data");
$data = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
