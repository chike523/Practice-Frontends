function validateForm() {
    var name = document.forms["contact"]["name"].value;
    var email = document.forms["contact"]["email"].value;
    var phone = document.forms["contact"]["phone"].value;
    var website = document.forms["contact"]["website"].value;
    var message = document.forms["contact"]["message"].value;
    var errorMessage = "";

    if (name == "") {
        errorMessage += "Name must be filled out.<br>";
    }
    if (email == "") {
        errorMessage += "Email must be filled out.<br>";
    }
    if (phone == "") {
        errorMessage += "Phone must be filled out.<br>";
    }
    if (website == "") {
        errorMessage += "Website must be filled out.<br>";
    }
    if (message == "") {
        errorMessage += "Message must be filled out.<br>";
    }

    if (errorMessage !== "") {
        document.getElementById("error-message").innerHTML = errorMessage;
        return false;
    }

    return true;
}
